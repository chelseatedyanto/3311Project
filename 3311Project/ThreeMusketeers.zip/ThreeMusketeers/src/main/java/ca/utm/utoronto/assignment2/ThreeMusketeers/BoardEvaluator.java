package ca.utm.utoronto.assignment2.ThreeMusketeers;

public interface BoardEvaluator {
    double evaluateBoard(Board board);
}
