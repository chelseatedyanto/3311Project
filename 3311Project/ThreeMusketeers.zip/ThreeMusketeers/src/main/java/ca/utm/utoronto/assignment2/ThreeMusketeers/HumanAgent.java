package ca.utm.utoronto.assignment2.ThreeMusketeers;

public class HumanAgent extends Agent {

    public HumanAgent(Board board) {
        super(board);
    }

    @Override
    public Move getMove() {
        return null;
    }
}
