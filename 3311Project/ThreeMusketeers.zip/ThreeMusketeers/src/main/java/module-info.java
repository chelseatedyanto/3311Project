module ca.utm.utoronto.assignment2.threemusketeers {
    requires javafx.controls;
    exports ca.utm.utoronto.assignment2.ThreeMusketeers;
}